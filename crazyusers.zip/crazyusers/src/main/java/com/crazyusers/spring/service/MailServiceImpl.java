package com.crazyusers.spring.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.mail.internet.MimeMessage;

import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.ui.velocity.VelocityEngineUtils;

import com.crazyusers.springmvc.model.ContactAdmin;
import com.crazyusers.springmvc.model.Wedding;
import com.crazyusers.springmvc.scheduler.EmailUser;
import com.crazyusers.springmvc.scheduler.Task;

import freemarker.template.Configuration;

@SuppressWarnings("deprecation")
@Service("mailService")
public class MailServiceImpl implements MailService {

	@Autowired
	JavaMailSender mailSender;

	@Autowired
	VelocityEngine velocityEngine;

	@Autowired
	Configuration freemarkerConfiguration;

	@Override
	public void sendEmail(Object object) {

		EmailUser user = (EmailUser) object;
		MimeMessagePreparator preparator = getMessagePreparator(user);

		try {
			mailSender.send(preparator);
		} catch (MailException ex) {
			System.err.println(ex.getMessage());
		}
	}

	private MimeMessagePreparator getMessagePreparator(final EmailUser user) {

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

				helper.setSubject("Wishing You Happy BirthDay...");
				helper.setFrom("re1t.sr@gmail.com");
				helper.setBcc("revanthkumar95@gmail.com");
				helper.setTo(user.getEmail());
				helper.setSentDate(new Date());
				helper.setValidateAddresses(true);
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("user", user);

				String text = geFreeMarkerTemplateContent(model);
				// System.out.println("Template content : "+text);

				// use the true flag to indicate you need a multipart message
				// helper.setText(text, true);

				// Additionally, let's add a resource as an attachment as well.
				// helper.addAttachment("birthday.png", new
				// ClassPathResource("birthday.png"));
				helper.setText(text + "<img src='cid:birthday'>", true);
				helper.addInline("birthday", new ClassPathResource("birthday.jpg"));

			}
		};
		return preparator;
	}

	public String geVelocityTemplateContent(Map<String, Object> model) {
		StringBuffer content = new StringBuffer();
		try {
			content.append(VelocityEngineUtils.mergeTemplateIntoString(velocityEngine,
					"/vmtemplates/velocity_mailTemplate.vm", model));
			return content.toString();
		} catch (Exception e) {
			System.out.println("Exception occured while processing velocity template:" + e.getMessage());
		}
		return "";
	}

	public String geFreeMarkerTemplateContent(Map<String, Object> model) {
		StringBuffer content = new StringBuffer();
		try {
			content.append(FreeMarkerTemplateUtils
					.processTemplateIntoString(freemarkerConfiguration.getTemplate("fm_mailTemplate.txt"), model));
			return content.toString();
		} catch (Exception e) {
			System.out.println("Exception occured while processing fmtemplate:" + e.getMessage());
		}
		return "";
	}

	@Override
	public void sendRegistrationEmail(Object object) {

		EmailUser user = (EmailUser) object;
		MimeMessagePreparator preparator = getRegistrationPreparator(user);

		try {
			mailSender.send(preparator);
		} catch (MailException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public String getRegistrationFreeMarkerTemplateContent(Map<String, Object> model) {
		StringBuffer content = new StringBuffer();
		try {
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(
					freemarkerConfiguration.getTemplate("fm_RegistrationTemplate.txt"), model));
			return content.toString();
		} catch (Exception e) {
			System.out.println("Exception occured while processing fmtemplate:" + e.getMessage());
		}
		return "";
	}

	private MimeMessagePreparator getRegistrationPreparator(final EmailUser user) {

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

				helper.setSubject("Your CrazyUsers Registration completed successfully");
				helper.setFrom("re1t.sr@gmail.com");
				helper.setBcc("revanthkumar95@gmail.com");
				helper.setTo(user.getEmail());
				helper.setSentDate(new Date());
				helper.setValidateAddresses(true);
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("user", user);

				String text = getRegistrationFreeMarkerTemplateContent(model);
				// System.out.println("Template content : "+text);
				// use the true flag to indicate you need a multipart message

				helper.setText(text, true);
			}
		};
		return preparator;
	}

	@Override
	public void sendTaskEmail(Object object) {

		Task task = (Task) object;
		MimeMessagePreparator preparator = getTaskPreparator(task);

		try {
			mailSender.send(preparator);
		} catch (MailException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public String getTaskFreeMarkerTemplateContent(Map<String, Object> model, Task task) {
		StringBuffer content = new StringBuffer();
		try {
			content.append(FreeMarkerTemplateUtils
					.processTemplateIntoString(freemarkerConfiguration.getTemplate(task.getTemplate_name()), model));
			return content.toString();
		} catch (Exception e) {
			System.out.println("Exception occured while processing fmtemplate:" + e.getMessage());
		}
		return "";
	}

	private MimeMessagePreparator getTaskPreparator(final Task task) {

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

				task.setName("Crazy User");
				helper.setSubject(task.getMessage());
				helper.setFrom("re1t.sr@gmail.com");
				helper.setCc("revanthkumar95@gmail.com");
				helper.setBcc(task.getEmailArr());
				helper.setSentDate(new Date());
				helper.setValidateAddresses(true);
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("task", task);

				String text = getTaskFreeMarkerTemplateContent(model, task);
				// System.out.println("Template content : "+text);

				// use the true flag to indicate you need a multipart message
				// helper.setText(text, true);

				// Additionally, let's add a resource as an attachment as well.
				// helper.addAttachment(task.getImage_name(), new
				// ClassPathResource(task.getImage_name()));
				String image = task.getImage_name().substring(task.getImage_name().lastIndexOf(".") + 1,
						task.getImage_name().length());
				helper.setText(text + "<img src='cid:" + image + "'>", true);
				helper.addInline(image, new ClassPathResource(task.getImage_name()));

			}
		};
		return preparator;
	}

	public String getWeddingFreeMarkerTemplateContent(Map<String, Object> model, Wedding wed) {
		StringBuffer content = new StringBuffer();
		try {
			content.append(FreeMarkerTemplateUtils
					.processTemplateIntoString(freemarkerConfiguration.getTemplate(wed.getTemplate_name()), model));
			return content.toString();
		} catch (Exception e) {
			System.out.println("Exception occured while processing fmtemplate:" + e.getMessage());
		}
		return "";
	}

	private MimeMessagePreparator getWeddingPreparator(final Wedding wed) {

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

				helper.setSubject("Wedding Greeting from Crazy Users !");
				helper.setFrom("re1t.sr@gmail.com");
				helper.setBcc("revanthkumar95@gmail.com");
				helper.setTo(wed.getEmail());
				helper.setSentDate(new Date());
				helper.setValidateAddresses(true);
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("wed", wed);

				String text = getWeddingFreeMarkerTemplateContent(model, wed);
				// System.out.println("Template content : "+text);

				// use the true flag to indicate you need a multipart message
				// helper.setText(text, true);

				// Additionally, let's add a resource as an attachment as well.
				// helper.addAttachment(wed.getImage_name(), new
				// ClassPathResource(wed.getImage_name()));

				helper.setText(text + "<img src='cid:wedding'>", true);
				helper.addInline("wedding", new ClassPathResource(wed.getImage_name()));

			}
		};
		return preparator;
	}

	@Override
	public void sendWeddingEmail(Object object) {
		Wedding wed = (Wedding) object;
		MimeMessagePreparator preparator = getWeddingPreparator(wed);

		try {
			mailSender.send(preparator);
		} catch (MailException ex) {
			System.err.println(ex.getMessage());
		}

	}

	@Override
	public void sendPasswordResetMail(Object object) {
		EmailUser user = (EmailUser) object;
		MimeMessagePreparator preparator = getPasswordResetPreparator(user);

		try {
			mailSender.send(preparator);
		} catch (MailException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public String getPasswordResetTemplateContent(Map<String, Object> model) {
		StringBuffer content = new StringBuffer();
		try {
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(
					freemarkerConfiguration.getTemplate("fm_PasswordResetTemplate.txt"), model));
			return content.toString();
		} catch (Exception e) {
			System.out.println("Exception occured while processing fmtemplate:" + e.getMessage());
		}
		return "";
	}

	private MimeMessagePreparator getPasswordResetPreparator(final EmailUser user) {

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

				helper.setSubject("Your CrazyUsers login password reset successfully");
				helper.setFrom("re1t.sr@gmail.com");
				helper.setBcc("revanthkumar95@gmail.com");
				helper.setTo(user.getEmail());
				helper.setSentDate(new Date());
				helper.setValidateAddresses(true);
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("user", user);

				String text = getPasswordResetTemplateContent(model);

				// use the true flag to indicate you need a multipart message
				helper.setText(text, true);

			}
		};
		return preparator;
	}

	@Override
	public void sendAdminRequetMail(Object object) {
		ContactAdmin user = (ContactAdmin) object;
		MimeMessagePreparator preparator = getAdminRequetPreparator(user);

		try {
			mailSender.send(preparator);
		} catch (MailException ex) {
			System.err.println(ex.getMessage());
		}
	}

	public String getAdminRequetTemplateContent(Map<String, Object> model) {
		StringBuffer content = new StringBuffer();
		try {
			content.append(FreeMarkerTemplateUtils.processTemplateIntoString(
					freemarkerConfiguration.getTemplate("fm_adminRequestTemplate.txt"), model));
			return content.toString();
		} catch (Exception e) {
			System.out.println("Exception occured while processing fmtemplate:" + e.getMessage());
		}
		return "";
	}

	private MimeMessagePreparator getAdminRequetPreparator(final ContactAdmin user) {

		MimeMessagePreparator preparator = new MimeMessagePreparator() {

			@Override
			public void prepare(MimeMessage mimeMessage) throws Exception {
				MimeMessageHelper helper = new MimeMessageHelper(mimeMessage, true);

				helper.setSubject("Request submitted successfully to CrazyUsers Admin");
				helper.setFrom("re1t.sr@gmail.com");
				helper.setBcc("revanthkumar95@gmail.com");
				helper.setTo(user.getFromEmailId());
				helper.setSentDate(new Date());
				helper.setValidateAddresses(true);
				Map<String, Object> model = new HashMap<String, Object>();
				model.put("user", user);

				String text = getAdminRequetTemplateContent(model);

				// use the true flag to indicate you need a multipart message
				helper.setText(text, true);

			}
		};
		return preparator;
	}
}
