package com.crazyusers.spring.service;

import com.crazyusers.springmvc.model.ContactAdmin;
import com.crazyusers.springmvc.model.Wedding;
import com.crazyusers.springmvc.scheduler.EmailUser;
import com.crazyusers.springmvc.scheduler.Task;

public interface EmailService {

	public void sendBirthDayMail(EmailUser user);

	public void sendRegistrationEmail(EmailUser user);

	public void sendPasswordResetMail(EmailUser user);

	public void sendTaskEmail(Task user);

	public void sendWeddingEmail(Wedding wed);
	
	public void sendAdminRequetMail(ContactAdmin user);

}
