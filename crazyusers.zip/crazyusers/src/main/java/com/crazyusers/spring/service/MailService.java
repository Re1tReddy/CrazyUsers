package com.crazyusers.spring.service;

public interface MailService {

	public void sendEmail(final Object object);

	public void sendRegistrationEmail(final Object object);
	
	public void sendPasswordResetMail(final Object object);

	public void sendTaskEmail(final Object object);
	
	public void sendWeddingEmail(final Object object);
	
	public void sendAdminRequetMail(final Object object);
}
