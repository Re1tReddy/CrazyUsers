package com.crazyusers.spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.crazyusers.springmvc.model.ContactAdmin;
import com.crazyusers.springmvc.model.Wedding;
import com.crazyusers.springmvc.scheduler.EmailUser;
import com.crazyusers.springmvc.scheduler.Task;

@Service("emailService")
public class EmailServiceImpl implements EmailService {

	@Autowired
	MailService mailService;

	@Override
	public void sendBirthDayMail(EmailUser user) {
		mailService.sendEmail(user);
	}

	@Override
	public void sendRegistrationEmail(EmailUser user) {
		mailService.sendRegistrationEmail(user);

	}

	@Override
	public void sendTaskEmail(Task user) {
		mailService.sendTaskEmail(user);
	}

	@Override
	public void sendWeddingEmail(Wedding wed) {

		mailService.sendWeddingEmail(wed);
	}

	@Override
	public void sendPasswordResetMail(EmailUser user) {
		mailService.sendPasswordResetMail(user);
	}

	@Override
	public void sendAdminRequetMail(ContactAdmin user) {
		mailService.sendAdminRequetMail(user);
	}

}
