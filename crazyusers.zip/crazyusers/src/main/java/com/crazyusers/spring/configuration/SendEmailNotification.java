package com.crazyusers.spring.configuration;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.crazyusers.spring.service.EmailService;
import com.crazyusers.springmvc.scheduler.EmailUser;
import com.crazyusers.springmvc.scheduler.Utills;
import com.mysql.jdbc.Statement;

public class SendEmailNotification {
	Utills util = new Utills();

	public static void main(String[] args) {

		SendEmailNotification send = new SendEmailNotification();

		send.sendRegistrationMail();
	}

	public void sendRegistrationMail() {

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmailService mail = (EmailService) context.getBean("emailService");
		EmailUser user = new EmailUser();

		user.setName("Revanth Reddy");
		user.setEmail("revanthkumar95@gmail.com");

		mail.sendRegistrationEmail(user);

		context.close();
	}

	public void sendBdayMail() {

		SendEmailNotification send = new SendEmailNotification();
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmailService orderService = (EmailService) context.getBean("emailService");
		for (EmailUser user : send.getUsers()) {
			orderService.sendBirthDayMail(user);
		}
		context.close();
	}

	public List<EmailUser> checkBirthDayDate(ResultSet rs, List<EmailUser> userList) throws SQLException {
		String dob = rs.getString("dob");
		String[] dobAray = dob.split("-");
		String year = dobAray[0];
		String month = dobAray[1];
		String day = dobAray[2];
		EmailUser user = new EmailUser();
		if (Utills.getCurrentMonth().equals(month) && Utills.getCurrentDay().equals(day)) {

			int curyear = Integer.valueOf(Utills.getCurrentYear());
			int dobyear = Integer.valueOf(year);
			int age = curyear - dobyear;

			user.setAge(age);
			user.setEmail(rs.getString("email"));
			user.setContactNo(Long.toString(rs.getLong("mobile")));
			user.setName(rs.getString("first_name"));
			user.setMesage(" you have turned up " + age + " years old !");
			userList.add(user);
		}
		return userList;
	}

	public List<EmailUser> getUsers() {
		List<EmailUser> userList = new ArrayList<EmailUser>();
		try {
			Statement stmt = (Statement) util.getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from APP_USER");
			while (rs.next()) {
				userList = checkBirthDayDate(rs, userList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userList;
	}

}
