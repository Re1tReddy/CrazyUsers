/**
 * 
 */
package com.crazyusers.springmvc.dao;

import java.util.List;

import com.crazyusers.springmvc.model.Wedding;

/**
 * @author revanthreddy
 *
 */
public interface WeddingDao {

	List<Wedding> findAllWeddings();

	Wedding findById(int id);

	void deleteWeddingById(int id);

	void saveWedding(Wedding wed);
}
