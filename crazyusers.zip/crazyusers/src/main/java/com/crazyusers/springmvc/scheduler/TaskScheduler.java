package com.crazyusers.springmvc.scheduler;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.crazyusers.spring.configuration.AppConfig;
import com.crazyusers.spring.configuration.SendEmailNotification;
import com.crazyusers.spring.service.EmailService;
import com.crazyusers.springmvc.model.User;
import com.crazyusers.springmvc.model.Wedding;
import com.mysql.jdbc.Statement;

@Configuration
@EnableScheduling
public class TaskScheduler {
	Utills util = new Utills();
	SendEmailNotification send = new SendEmailNotification();

	@Scheduled(cron = "0 0 01 * * *", zone = "IST")
	public void scheduleBirthDayTasks() {
		System.out.println("schedule birthday tasks using cron jobs - " + new Date());

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmailService emailService = (EmailService) context.getBean("emailService");
		for (EmailUser user : send.getUsers()) {
			emailService.sendBirthDayMail(user);
			//SendSMS.sendBirthDaySMS(user);
		}
		context.close();
	}

	@Scheduled(cron = "0 0 02 * * *", zone = "IST")
	public void scheduleWeddings() {
		System.out.println("schedule wedding tasks using cron jobs - " + new Date());

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmailService emailService = (EmailService) context.getBean("emailService");

		try {
			Statement stmt = (Statement) util.getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from WEDDING");

			while (rs.next()) {
				Wedding wed = new Wedding();
				String dob = rs.getString("wedding_date");
				String[] dobAray = dob.split("-");
				String year = dobAray[0];
				String month = dobAray[1];
				String day = dobAray[2];
				if (Utills.getCurrentMonth().equals(month) && Utills.getCurrentDay().equals(day)) {

					int curyear = Integer.valueOf(Utills.getCurrentYear());
					int dobyear = Integer.valueOf(year);
					int anniversary = curyear - dobyear;
					if (anniversary > 0) {
						wed.setMessage("Enjoy your " + anniversary + " Anniversary !");
					} else {
						wed.setMessage("Enjoy your Anniversary !");
					}

					wed.setImage_name(rs.getString("image_name"));
					wed.setTemplate_name(rs.getString("template_name"));

					wed.setHusband_name(rs.getString("husband_name"));
					wed.setWife_name(rs.getString("wife_name"));
					wed.setEmail(rs.getString("email"));
					emailService.sendWeddingEmail(wed);

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		context.close();
	}

	// @Scheduled(cron = "0 0/5 * * * ?", zone = "IST")
	// @Scheduled(cron = "0 30 3 1/1 * ? *", zone = "UTC")
	@Scheduled(cron = "0 0 03 * * *", zone = "IST")
	public void scheduleTasks() {
		System.out.println("schedule tasks using cron jobs - " + new Date());

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmailService emailService = (EmailService) context.getBean("emailService");

		try {
			Statement stmt = (Statement) util.getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from TASKS");

			while (rs.next()) {
				Task task = new Task();
				String dob = rs.getString("event_date");

				String[] dobAray = dob.split("-");
				String month = dobAray[1];
				String day = dobAray[2];
				if (Utills.getCurrentMonth().equals(month) && Utills.getCurrentDay().equals(day)) {

					task.setImage_name(rs.getString("image_name"));
					task.setTemplate_name(rs.getString("template_name"));
					task.setMessage(rs.getString("message"));
					task.setEmailArr(getEmailsList());

					emailService.sendTaskEmail(task);
					//SendSMS.sendEventSMS(task);

				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		context.close();
	}

	public List<EmailUser> checkBirthDayDate(ResultSet rs, List<EmailUser> userList) throws SQLException {
		String dob = rs.getString("dob");
		String[] dobAray = dob.split("-");
		String year = dobAray[0];
		String month = dobAray[1];
		String day = dobAray[2];
		EmailUser user = new EmailUser();
		if (Utills.getCurrentMonth().equals(month) && Utills.getCurrentDay().equals(day)) {

			int curyear = Integer.valueOf(Utills.getCurrentYear());
			int dobyear = Integer.valueOf(year);
			int age = curyear - dobyear;

			user.setAge(age);
			user.setEmail(rs.getString("email"));

			user.setName(rs.getString("first_name"));
			user.setMesage("you have turned up " + age + " years old !");
			userList.add(user);
		}
		return userList;
	}

	public List<EmailUser> getUsers() {
		List<EmailUser> userList = new ArrayList<EmailUser>();
		try {
			Statement stmt = (Statement) util.getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from APP_USER");
			while (rs.next()) {
				userList = checkBirthDayDate(rs, userList);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userList;
	}

	public List<User> getUsersList() {
		List<User> userList = new ArrayList<User>();
		try {
			Statement stmt = (Statement) util.getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from APP_USER");
			while (rs.next()) {
				User user = new User();
				user.setEmail(rs.getString("email"));
				user.setFirstName(rs.getString("first_name"));
				user.setLastName(rs.getString("last_name"));
				userList.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userList;
	}

	public String[] getEmailsList() {
		List<String> emailList = new ArrayList<String>();
		try {
			Statement stmt = (Statement) util.getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select email from APP_USER");
			while (rs.next()) {
				emailList.add(rs.getString("email"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		String[] emailArr = emailList.toArray(new String[emailList.size()]);
		return emailArr;
	}

}
