package com.crazyusers.springmvc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author revanthreddy
 */

@Entity
@Table(name = "TASKS")
public class Task implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotNull(message = "Event Name should not be empty")
	@Column(name = "EVENT_NAME", nullable = false)
	private String event_name;
	
	@NotNull(message = "Template Name should not be empty")
	@Column(name = "TEMPLATE_NAME", nullable = false)
	private String template_name;
	
	@DOBValidator
	@NotEmpty(message = "Date should not be empty")
	@Column(name = "EVENT_DATE", nullable = false)
	private String event_date;
	
	@NotNull(message = "Image Name should not be empty")
	@Column(name = "IMAGE_NAME", nullable = false)
	private String image_name;
	
	@NotNull(message = "Message should not be empty")
	@Column(name = "MESSAGE", nullable = false)
	private String message;

	public String getEvent_name() {
		return event_name;
	}

	public void setEvent_name(String event_name) {
		this.event_name = event_name;
	}

	public String getTemplate_name() {
		return template_name;
	}

	public void setTemplate_name(String template_name) {
		this.template_name = template_name;
	}

	public String getEvent_date() {
		return event_date;
	}

	public void setEvent_date(String event_date) {
		this.event_date = event_date;
	}

	public String getImage_name() {
		return image_name;
	}

	public void setImage_name(String image_name) {
		this.image_name = image_name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Task [id=" + id + ", event_name=" + event_name + ", template_name=" + template_name + ", event_date="
				+ event_date + ", image_name=" + image_name + ", message=" + message + "]";
	}

}
