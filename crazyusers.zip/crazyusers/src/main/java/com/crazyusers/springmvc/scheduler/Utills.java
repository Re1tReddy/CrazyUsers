package com.crazyusers.springmvc.scheduler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author revanthreddy
 *
 */
public class Utills {

	private static TimeZone tz = TimeZone.getTimeZone("IST");

	public Connection getJDBConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "ubuntu", "Root@123");

			if (connection != null) {
				System.out.println("You made it, take control your database now!");
			} else {
				System.out.println("Failed to make connection!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	public static String getCurrentYear() {
		String pattern = "yyyy";
		Date date = new Date();
		date.setTime(date.getTime());
		return getDateFormater(pattern).format(date);
	}

	public static String getCurrentMonth() {
		String pattern = "MM";
		Date date = new Date();
		date.setTime(date.getTime());
		return getDateFormater(pattern).format(date);
	}

	public static String getCurrentDay() {
		String pattern = "dd";
		Date date = new Date();
		date.setTime(date.getTime());
		return getDateFormater(pattern).format(date);
	}

	public static SimpleDateFormat getDateFormater(String pattern) {
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		format.setTimeZone(tz);
		return format;
	}

	public static String getNextDate() {
		Calendar cal = Calendar.getInstance();
		cal.add(Calendar.DATE, +1);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMdd");
		dateFormat.setTimeZone(tz);
		return dateFormat.format(cal.getTime());
	}

	public static String greetUser() {
		String pattern = "HH";
		Date date = new Date();
		date.setTime(date.getTime());
		String wish = "Good Morning";
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		format.setTimeZone(tz);
		int hour = Integer.parseInt(format.format(date));
		if (hour > 0 && hour <= 11) {
			wish = "Good Morning";
		} else if (hour >= 12 && hour <= 15) {
			wish = "Good AfterNoon";
		} else if (hour >= 15 && hour <= 18) {
			wish = "Good Evening";
		} else {
			wish = "Have a Pleasant Night";
		}
		return wish;
	}
}
