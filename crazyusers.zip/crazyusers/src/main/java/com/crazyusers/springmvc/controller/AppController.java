package com.crazyusers.springmvc.controller;

import java.util.List;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.security.authentication.AuthenticationTrustResolver;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.rememberme.PersistentTokenBasedRememberMeServices;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.crazyusers.spring.configuration.AppConfig;
import com.crazyusers.spring.service.EmailService;
import com.crazyusers.springmvc.model.ContactAdmin;
import com.crazyusers.springmvc.model.Task;
import com.crazyusers.springmvc.model.User;
import com.crazyusers.springmvc.model.UserProfile;
import com.crazyusers.springmvc.model.Wedding;
import com.crazyusers.springmvc.scheduler.EmailUser;
import com.crazyusers.springmvc.scheduler.Utills;
import com.crazyusers.springmvc.service.TaskService;
import com.crazyusers.springmvc.service.UserProfileService;
import com.crazyusers.springmvc.service.UserService;
import com.crazyusers.springmvc.service.WeddingService;

@Controller
@RequestMapping("/")
@SessionAttributes("roles")
public class AppController {

	@Autowired
	UserService userService;

	@Autowired
	TaskService taskService;

	@Autowired
	WeddingService weddingService;

	@Autowired
	UserProfileService userProfileService;

	@Autowired
	MessageSource messageSource;

	@Autowired
	PersistentTokenBasedRememberMeServices persistentTokenBasedRememberMeServices;

	@Autowired
	AuthenticationTrustResolver authenticationTrustResolver;

	Utills util = new Utills();
	ExecutorService executor = Executors.newFixedThreadPool(10);

	/**
	 * This method will list all existing users.
	 */
	@RequestMapping(value = { "/", "/list" }, method = RequestMethod.GET)
	public String listUsers(ModelMap model) {

		model.addAttribute("greet", Utills.greetUser());
		if (getPrincipal().equalsIgnoreCase("guest")) {
			User user = new User();
			model.addAttribute("user", user);
			model.addAttribute("edit", false);
			model.addAttribute("loggedinuser", "guest");
			return "redirect:/newuser";
		} else {
			List<User> users = userService.findAllUsers();
			String day = Utills.getNextDate();
			int usersCount = users.size();
			model.addAttribute("usersCount", usersCount);
			model.addAttribute("bday", day);
			model.addAttribute("users", users);
			model.addAttribute("loggedinuser", getPrincipal());
			return "userslist";
		}
	}

	/**
	 * This method will provide the medium to reset password.
	 */
	@RequestMapping(value = { "/forgotPassword" }, method = RequestMethod.GET)
	public String forgotPassword(ModelMap model) {
		User user = new User();
		model.addAttribute("user", user);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", "guest");
		return "forgotPassword";
	}

	/**
	 * This method will provide the medium to reset password.
	 */
	@RequestMapping(value = { "/forgotPassword" }, method = RequestMethod.POST)
	public String resetPassword(User user, BindingResult result, ModelMap model) {
		System.out.println("Email id :  " + user.getEmail());

		final User entity = userService.findByEmailId(user.getEmail());

		if (entity != null) {
			String password = generatRandomPassword();
			entity.setPassword(password);
			userService.updateUser(entity);
			model.addAttribute("message", "success");
			model.addAttribute("user", entity);
			model.addAttribute("loggedinuser", entity.getFirstName());

			// Executing methods in parallel
			FutureTask<Boolean> futureTask = new FutureTask<Boolean>(new Callable<Boolean>() {
				@Override
				public Boolean call() {
					sendPasswordResetMail(entity);
					return false;
				}
			});
			executor.execute(futureTask);

		} else {
			model.addAttribute("error", "success");
		}

		return "forgotPassword";
	}

	/**
	 * This method will provide the medium to add a new user.
	 */
	@RequestMapping(value = { "/newuser" }, method = RequestMethod.GET)
	public String newUser(ModelMap model) {
		User user = new User();
		model.addAttribute("user", user);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		return "registration";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * saving user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/newuser" }, method = RequestMethod.POST)
	public String saveUser(@Valid final User user, BindingResult result, ModelMap model) {
		model.addAttribute("greet", Utills.greetUser());
		if (result.hasErrors()) {
			return "registration";
		}

		if (!userService.isUserSSOUnique(user.getId(), user.getSsoId())) {
			FieldError ssoError = new FieldError("user", "ssoId", messageSource.getMessage("non.unique.ssoId",
					new String[] { user.getSsoId() }, Locale.getDefault()));
			result.addError(ssoError);
			return "registration";
		}

		User entity = userService.findByEmailId(user.getEmail());
		if (entity != null) {
			FieldError emailError = new FieldError("user", "email", messageSource.getMessage("non.unique.email",
					new String[] { user.getEmail() }, Locale.getDefault()));
			result.addError(emailError);
			return "registration";
		}
		if (user != null) {
			String dob = user.getDob();
			String[] dobAray = dob.split("-");
			int year = Integer.valueOf(dobAray[0]);
			int month = Integer.valueOf(dobAray[1]);
			int day = Integer.valueOf(dobAray[2]);
			int curyear = Integer.valueOf(Utills.getCurrentYear());
			if (year >= curyear) {
				FieldError yearError = new FieldError("user", "dob", messageSource.getMessage("dob.year.validation",
						new String[] { Utills.getCurrentYear() }, Locale.getDefault()));
				result.addError(yearError);
				return "registration";
			}

			if (month > 12) {
				FieldError yearError = new FieldError("user", "dob",
						messageSource.getMessage("dob.month.validation", new String[] { "12" }, Locale.getDefault()));
				result.addError(yearError);
				return "registration";
			}
			if (day > 31) {
				FieldError yearError = new FieldError("user", "dob",
						messageSource.getMessage("dob.day.validation", new String[] { "31" }, Locale.getDefault()));
				result.addError(yearError);
				return "registration";
			}

		}

		userService.saveUser(user);

		model.addAttribute("success", "Dear " + user.getFirstName() + ", your Registration completed successfully");
		model.addAttribute("message",
				"We have also sent you a confirmation mail to your email address : " + user.getEmail());
		model.addAttribute("loggedinuser", getPrincipal());

		if (!getPrincipal().equalsIgnoreCase("admin")) {

			// Executing methods in parallel
			FutureTask<Boolean> futureTask = new FutureTask<Boolean>(new Callable<Boolean>() {
				@Override
				public Boolean call() {
					sendRegistrationMail(user);
					// SendSMS.sendRegistrationSMS(user);
					return false;
				}
			});
			executor.execute(futureTask);

			return "registrationsuccess";
		} else {
			return "redirect:/list";
		}
	}

	public void sendRegistrationMail(User user) {

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmailService mail = (EmailService) context.getBean("emailService");
		EmailUser mailuser = new EmailUser();
		mailuser.setName(user.getFirstName());
		mailuser.setEmail(user.getEmail());
		mail.sendRegistrationEmail(mailuser);
		context.close();
	}

	public void sendPasswordResetMail(User user) {

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmailService mail = (EmailService) context.getBean("emailService");
		EmailUser mailuser = new EmailUser();

		mailuser.setLoginId(user.getSsoId());
		mailuser.setPassword(user.getPassword());
		mailuser.setName(user.getFirstName());
		mailuser.setEmail(user.getEmail());

		mail.sendPasswordResetMail(mailuser);

		context.close();
	}

	public void sendAdminRequetMail(ContactAdmin user) {

		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		EmailService mail = (EmailService) context.getBean("emailService");
		mail.sendAdminRequetMail(user);

		context.close();
	}

	/**
	 * This method will provide the medium to update an existing user.
	 */
	@RequestMapping(value = { "/edit-user-{ssoId}" }, method = RequestMethod.GET)
	public String editUser(@PathVariable String ssoId, ModelMap model) {
		User user = userService.findBySSO(ssoId);
		model.addAttribute("user", user);
		model.addAttribute("edit", true);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		return "registration";
	}

	/**
	 * This method will be called on form submission, handling POST request for
	 * updating user in database. It also validates the user input
	 */
	@RequestMapping(value = { "/edit-user-{ssoId}" }, method = RequestMethod.POST)
	public String updateUser(@Valid User user, BindingResult result, ModelMap model, @PathVariable String ssoId) {
		model.addAttribute("greet", Utills.greetUser());
		if (result.hasErrors()) {
			return "registration";
		}

		// Uncomment below 'if block' if you WANT TO ALLOW UPDATING SSO_ID in
		// UI which is a unique key to a User.
		if (!userService.isUserSSOUnique(user.getId(), user.getSsoId())) {
			FieldError ssoError = new FieldError("user", "ssoId", messageSource.getMessage("non.unique.ssoId",
					new String[] { user.getSsoId() }, Locale.getDefault()));
			result.addError(ssoError);
			return "registration";
		}
		User entity = userService.findById(user.getId());
		if (entity.getEmail().equalsIgnoreCase(user.getEmail())) {
			userService.updateUser(user);
		} else {
			User userEntity = userService.findByEmailId(user.getEmail());
			if (userEntity != null) {
				FieldError emailError = new FieldError("user", "email", messageSource.getMessage("non.unique.email",
						new String[] { user.getEmail() }, Locale.getDefault()));
				result.addError(emailError);
				return "registration";
			} else {
				userService.updateUser(user);
			}
		}
		if (user != null) {
			String dob = user.getDob();
			String[] dobAray = dob.split("-");
			int year = Integer.valueOf(dobAray[0]);
			int month = Integer.valueOf(dobAray[1]);
			int day = Integer.valueOf(dobAray[2]);
			int curyear = Integer.valueOf(Utills.getCurrentYear());
			if (year >= curyear) {
				FieldError yearError = new FieldError("user", "dob", messageSource.getMessage("dob.year.validation",
						new String[] { Utills.getCurrentYear() }, Locale.getDefault()));
				result.addError(yearError);
				return "registration";
			}

			if (month > 12) {
				FieldError yearError = new FieldError("user", "dob",
						messageSource.getMessage("dob.month.validation", new String[] { "12" }, Locale.getDefault()));
				result.addError(yearError);
				return "registration";
			}
			if (day > 31) {
				FieldError yearError = new FieldError("user", "dob",
						messageSource.getMessage("dob.day.validation", new String[] { "31" }, Locale.getDefault()));
				result.addError(yearError);
				return "registration";
			}

		}
		model.addAttribute("success",
				"Dear " + getPrincipal() + ", " + user.getFirstName() + " details has been updated successfully");
		model.addAttribute("loggedinuser", getPrincipal());

		if (getPrincipal().equalsIgnoreCase("admin")) {
			return "redirect:/list";
		}
		return "registrationsuccess";
	}

	/**
	 * This method will delete an user by it's SSOID value.
	 */
	@RequestMapping(value = { "/delete-user-{ssoId}" }, method = RequestMethod.GET)
	public String deleteUser(@PathVariable String ssoId) {
		userService.deleteUserBySSO(ssoId);
		return "redirect:/list";
	}

	/**
	 * This method will provide UserProfile list to views
	 */
	@ModelAttribute("roles")
	public List<UserProfile> initializeProfiles() {
		return userProfileService.findAll();
	}

	/**
	 * This method handles Access-Denied redirect.
	 */
	@RequestMapping(value = "/Access_Denied", method = RequestMethod.GET)
	public String accessDeniedPage(ModelMap model) {
		model.addAttribute("loggedinuser", getPrincipal());
		return "accessDenied";
	}

	/**
	 * This method handles login GET requests. If users is already logged-in and
	 * tries to goto login page again, will be redirected to list page.
	 */
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String loginPage() {

		if (isCurrentAuthenticationAnonymous()) {
			return "login";
		} else {
			return "redirect:/list";
		}
	}

	/**
	 * This method handles logout requests. Toggle the handlers if you are
	 * RememberMe functionality is useless in your app.
	 */
	@RequestMapping(value = "/logout", method = RequestMethod.GET)
	public String logoutPage(HttpServletRequest request, HttpServletResponse response) {
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		if (auth != null) {
			// new SecurityContextLogoutHandler().logout(request, response,
			// auth);
			persistentTokenBasedRememberMeServices.logout(request, response, auth);
			SecurityContextHolder.getContext().setAuthentication(null);
		}
		return "redirect:/login?logout";
	}

	/**
	 * This method returns the principal[user-name] of logged-in user.
	 */
	private String getPrincipal() {
		String userName = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();

		if (principal instanceof UserDetails) {
			userName = ((UserDetails) principal).getUsername();
		} else {
			userName = principal.toString();
		}
		return userName;
	}

	/**
	 * This method returns true if users is already authenticated [logged-in],
	 * else false.
	 */
	private boolean isCurrentAuthenticationAnonymous() {
		final Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		return authenticationTrustResolver.isAnonymous(authentication);
	}

	/**
	 * This method will provide the medium to update an existing task.
	 */
	@RequestMapping(value = { "/edit-task-{id}" }, method = RequestMethod.GET)
	public String editTask(@PathVariable int id, ModelMap model) {
		Task task = taskService.findById(id);
		model.addAttribute("task", task);
		model.addAttribute("edit", true);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		return "taskregistration";
	}

	@RequestMapping(value = { "/edit-task-{id}" }, method = RequestMethod.POST)
	public String updateTask(@Valid Task task, BindingResult result, ModelMap model, @PathVariable String id) {

		if (result.hasErrors()) {
			return "taskregistration";
		}
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		taskService.updateTask(task);

		return "redirect:/listtasks";
	}

	/**
	 * This method will delete a task.
	 */
	@RequestMapping(value = { "/delete-task-{id}" }, method = RequestMethod.GET)
	public String deleteTask(@PathVariable int id) {
		taskService.deleteTaskById(id);
		return "redirect:/listtasks";
	}

	/**
	 * This method will provide the medium to add a new task.
	 */
	@RequestMapping(value = { "/newtask" }, method = RequestMethod.GET)
	public String newTask(ModelMap model) {
		Task task = new Task();
		model.addAttribute("task", task);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		return "taskregistration";
	}

	@RequestMapping(value = { "/newtask" }, method = RequestMethod.POST)
	public String saveTask(@Valid Task task, BindingResult result, ModelMap model) {

		if (result.hasErrors()) {
			return "taskregistration";
		}
		model.addAttribute("loggedinuser", getPrincipal());
		taskService.saveTask(task);
		return "redirect:/listtasks";
	}

	/**
	 * This method will list all existing tasks.
	 */
	@RequestMapping(value = { "/listtasks" }, method = RequestMethod.GET)
	public String listTasks(ModelMap model) {

		List<Task> tasks = taskService.findAllTasks();
		int tasksCount = tasks.size();
		String month = Utills.getCurrentMonth();
		String day = Utills.getCurrentDay();
		model.addAttribute("bmonth", month);
		model.addAttribute("bday", day);
		model.addAttribute("tasksCount", tasksCount);
		model.addAttribute("tasks", tasks);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		return "taskslist";
	}

	/**
	 * This method will provide the medium to update an existing wedding.
	 */
	@RequestMapping(value = { "/edit-wedding-{id}" }, method = RequestMethod.GET)
	public String editWedding(@PathVariable int id, ModelMap model) {
		Wedding wedding = weddingService.findById(id);
		model.addAttribute("wedding", wedding);
		model.addAttribute("edit", true);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		return "weddingregistration";
	}

	@RequestMapping(value = { "/edit-wedding-{id}" }, method = RequestMethod.POST)
	public String updateWedding(@Valid Wedding wedding, BindingResult result, ModelMap model, @PathVariable String id) {

		if (result.hasErrors()) {
			return "weddingregistration";
		}
		model.addAttribute("loggedinuser", getPrincipal());
		weddingService.updateWedding(wedding);
		model.addAttribute("greet", Utills.greetUser());
		return "redirect:/listweddings";
	}

	/**
	 * This method will delete a wedding.
	 */
	@RequestMapping(value = { "/delete-wedding-{id}" }, method = RequestMethod.GET)
	public String deleteWedding(@PathVariable int id) {
		weddingService.deleteWeddingById(id);
		return "redirect:/listweddings";
	}

	/**
	 * This method will provide the medium to add a new wedding.
	 */
	@RequestMapping(value = { "/newwedding" }, method = RequestMethod.GET)
	public String newWedding(ModelMap model) {
		Wedding wedding = new Wedding();
		model.addAttribute("wedding", wedding);
		model.addAttribute("edit", false);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		return "weddingregistration";
	}

	@RequestMapping(value = { "/newwedding" }, method = RequestMethod.POST)
	public String saveWedding(@Valid Wedding wedding, BindingResult result, ModelMap model) {

		if (result.hasErrors()) {
			return "weddingregistration";
		}
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		weddingService.saveWedding(wedding);
		return "redirect:/listweddings";
	}

	/**
	 * This method will list all existing weddings.
	 */
	@RequestMapping(value = { "/listweddings" }, method = RequestMethod.GET)
	public String listWeddings(ModelMap model) {

		List<Wedding> weds = weddingService.findAllWeddings();
		int wedsCount = weds.size();
		String month = Utills.getCurrentMonth();
		String day = Utills.getCurrentDay();
		model.addAttribute("bmonth", month);
		model.addAttribute("bday", day);
		model.addAttribute("wedsCount", wedsCount);
		model.addAttribute("weds", weds);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		return "weddingslist";
	}

	public static String generatRandomPassword() {
		int count = 5;
		final String ALPHA_NUMERIC_STRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%&*";
		StringBuilder builder = new StringBuilder();
		while (count-- != 0) {
			int character = (int) (Math.random() * ALPHA_NUMERIC_STRING.length());
			builder.append(ALPHA_NUMERIC_STRING.charAt(character));
		}
		return builder.toString();
	}

	/**
	 * This method will provide the medium to reset password.
	 */
	@RequestMapping(value = { "/contactAdmin" }, method = RequestMethod.GET)
	public String contactAdminPage(ModelMap model) {
		ContactAdmin user = new ContactAdmin();
		model.addAttribute("user", user);
		model.addAttribute("edit", true);
		model.addAttribute("loggedinuser", getPrincipal());
		model.addAttribute("greet", Utills.greetUser());
		if (getPrincipal().equalsIgnoreCase("anonymousUser")) {
			model.addAttribute("edit", false);
		}
		return "contactAdmin";
	}

	/**
	 * This method will provide the medium to reset password.
	 */
	@RequestMapping(value = { "/contactAdmin" }, method = RequestMethod.POST)
	public String contactAdmin(@Valid final ContactAdmin user, BindingResult result, ModelMap model) {
		final User entity = userService.findByEmailId(user.getFromEmailId());
		model.addAttribute("user", user);
		if (entity != null) {
			user.setName(entity.getFirstName());
			model.addAttribute("message", "Request submitted successfully,We will get back to you with resolution.");

			// Executing methods in parallel
			FutureTask<Boolean> futureTask = new FutureTask<Boolean>(new Callable<Boolean>() {
				@Override
				public Boolean call() {
					sendAdminRequetMail(user);
					return false;
				}
			});
			executor.execute(futureTask);

		} else {
			model.addAttribute("error", "Given Email-Id is not registered,Please Sing-up.");
		}

		return "contactAdmin";
	}

}