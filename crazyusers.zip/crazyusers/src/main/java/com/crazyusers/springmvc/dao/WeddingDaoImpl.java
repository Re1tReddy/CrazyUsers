package com.crazyusers.springmvc.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.crazyusers.springmvc.model.Wedding;

/**
 * @author revanthreddy
 *
 */

@Repository("weddingDao")
public class WeddingDaoImpl extends AbstractDao<Integer, Wedding> implements WeddingDao {

	@Override
	@SuppressWarnings("unchecked")
	public List<Wedding> findAllWeddings() {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("husband_name"));
		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY); // To
																					// avoid
																					// duplicates.
		List<Wedding> wed = criteria.list();

		return wed;
	}

	@Override
	public Wedding findById(int id) {
		Wedding wed = getByKey(id);
		return wed;
	}

	@Override
	public void deleteWeddingById(int id) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("id", id));
		Wedding wed = (Wedding) crit.uniqueResult();
		delete(wed);

	}

	@Override
	public void saveWedding(Wedding wed) {
		persist(wed);

	}

}
