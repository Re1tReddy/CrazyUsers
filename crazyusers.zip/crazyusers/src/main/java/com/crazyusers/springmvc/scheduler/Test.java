package com.crazyusers.springmvc.scheduler;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.TimeZone;

import com.crazyusers.springmvc.model.User;
import com.mysql.jdbc.Statement;

public class Test {
	private static TimeZone tz = TimeZone.getTimeZone("UTC");
	Utills util = new Utills();

	public Connection getJDBConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/demo", "root", "Aruba@123");

			if (connection != null) {
				System.out.println("You made it, take control your database now!");
			} else {
				System.out.println("Failed to make connection!");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return connection;
	}

	public static String getCurrentYear() {
		String pattern = "yyyy";
		Date date = new Date();
		date.setTime(date.getTime());
		return getDateFormater(pattern).format(date);
	}

	public static String getCurrentMonth() {
		String pattern = "MM";
		Date date = new Date();
		date.setTime(date.getTime());
		return getDateFormater(pattern).format(date);
	}

	public static String getCurrentDay() {
		String pattern = "dd";
		Date date = new Date();
		date.setTime(date.getTime());
		return getDateFormater(pattern).format(date);
	}

	public static SimpleDateFormat getDateFormater(String pattern) {
		SimpleDateFormat format = new SimpleDateFormat(pattern);
		format.setTimeZone(tz);
		return format;
	}

	public void checkBirthDayDate(ResultSet rs) throws SQLException {
		String dob = rs.getString("dob");
		String[] dobAray = dob.split("-");
		String year = dobAray[0];
		String month = dobAray[1];
		String day = dobAray[2];

		System.out.println(year + "  " + getCurrentYear());
		System.out.println(month + "  " + getCurrentMonth());
		System.out.println(day + "  " + getCurrentDay());

		if (getCurrentMonth().equals(month) && getCurrentDay().equals(day)) {

			int curyear = Integer.valueOf(getCurrentYear());
			int dobyear = Integer.valueOf(year);
			int diff = curyear - dobyear;

			System.out.println("Hi " + rs.getString("first_name") + " you have turned up " + diff + " years old !");

			System.out.println(rs.getString("first_name") + "  " + rs.getString("dob") + "  " + rs.getString("email"));
		}

	}

	public void getUsers() {
		try {
			Statement stmt = (Statement) getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from APP_USER");
			while (rs.next()) {

				checkBirthDayDate(rs);

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public List<User> getUsersList() {
		List<User> userList = new ArrayList<User>();
		try {
			Statement stmt = (Statement) util.getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select * from APP_USER");
			while (rs.next()) {
				User user = new User();
				user.setEmail(rs.getString("email"));
				user.setFirstName(rs.getString("first_name"));
				user.setLastName(rs.getString("last_name"));
				userList.add(user);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return userList;
	}

	public String[] getEmailsList() {
		List<String> emailList = new ArrayList<String>();
		try {
			Statement stmt = (Statement) util.getJDBConnection().createStatement();
			ResultSet rs = stmt.executeQuery("select email from APP_USER");
			while (rs.next()) {
				emailList.add(rs.getString("email"));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		String[] emailArr = emailList.toArray(new String[emailList.size()]);
		return emailArr;
	}

	public static void main(String[] args) {
		Test test = new Test();
		String[] emailArr = test.getEmailsList();

		for (String em : emailArr) {
			System.out.println(em);
		}

	}

}
