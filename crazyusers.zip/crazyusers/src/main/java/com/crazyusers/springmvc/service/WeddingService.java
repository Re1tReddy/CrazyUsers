/**
 * 
 */
package com.crazyusers.springmvc.service;

import java.util.List;

import com.crazyusers.springmvc.model.Wedding;

/**
 * @author revanthreddy
 *
 */
public interface WeddingService {

	List<Wedding> findAllWeddings();

	Wedding findById(int id);

	void deleteWeddingById(int id);

	void saveWedding(Wedding wed);

	void updateWedding(Wedding wed);
}
