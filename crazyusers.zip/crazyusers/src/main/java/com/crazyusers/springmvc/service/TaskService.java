/**
 * 
 */
package com.crazyusers.springmvc.service;

import java.util.List;

import com.crazyusers.springmvc.model.Task;

/**
 * @author revanthreddy
 *
 */
public interface TaskService {

	List<Task> findAllTasks();

	void updateTask(Task task);

	Task findById(int id);

	void deleteTaskById(int id);

	void saveTask(Task task);
}
