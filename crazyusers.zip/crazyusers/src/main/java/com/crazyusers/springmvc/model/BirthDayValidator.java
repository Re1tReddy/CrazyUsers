package com.crazyusers.springmvc.model;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class BirthDayValidator implements ConstraintValidator<DOBValidator, String> {

	
	@Override
	public void initialize(DOBValidator dob) { }

	@Override
	public boolean isValid(String dob, ConstraintValidatorContext cxt) {
		if(dob == null) {
			return false;
		}
		return dob.matches("\\d{4}-\\d{2}-\\d{2}");
	}
}
