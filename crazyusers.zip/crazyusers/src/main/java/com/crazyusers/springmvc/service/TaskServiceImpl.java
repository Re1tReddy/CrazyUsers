/**
 * 
 */
package com.crazyusers.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crazyusers.springmvc.dao.TaskDao;
import com.crazyusers.springmvc.model.Task;

/**
 * @author revanthreddy
 *
 */

@Service("taskService")
@Transactional
public class TaskServiceImpl implements TaskService {

	@Autowired
	private TaskDao dao;

	@Override
	public List<Task> findAllTasks() {
		return dao.findAllTasks();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.crazyusers.springmvc.service.TaskService#updateTask(com.crazyusers.
	 * springmvc.model.Task)
	 */
	@Override
	public void updateTask(Task task) {
		Task entity = dao.findById(task.getId());
		if (entity != null) {
			entity.setEvent_date(task.getEvent_date().trim());
			entity.setEvent_name(task.getEvent_name());
			entity.setImage_name(task.getImage_name());
			entity.setMessage(task.getMessage());
			entity.setTemplate_name(task.getTemplate_name());
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.crazyusers.springmvc.service.TaskService#findById(int)
	 */
	@Override
	public Task findById(int id) {

		return dao.findById(id);
	}

	/* (non-Javadoc)
	 * @see com.crazyusers.springmvc.service.TaskService#deleteTaskById(int)
	 */
	@Override
	public void deleteTaskById(int id) {
		dao.deleteTaskById(id);
		
	}

	/* (non-Javadoc)
	 * @see com.crazyusers.springmvc.service.TaskService#saveTask(com.crazyusers.springmvc.model.Task)
	 */
	@Override
	public void saveTask(Task task) {
		dao.saveTask(task);
		
	}
}
