package com.crazyusers.springmvc.scheduler;

import com.crazyusers.springmvc.model.User;
import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class SendSMS {

	// Find your Account Sid and Token at twilio.com/user/account
	public static final String ACCOUNT_SID = "AC418055d9472701d9afb5207e735642b6";
	public static final String AUTH_TOKEN = "97649c4545772a79cb0ae936131c0734";

	public static void sendBirthDaySMS(EmailUser user) {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		String mobile = "+91" + user.getContactNo();

		Message message = Message.creator(new PhoneNumber(mobile), new PhoneNumber("+16199285746"),
				"Dear " + user.getName() + "\n" + ", Have a wonderful birthday." + "\n"
						+ " I wish your every day to be filled with lots of love, laughter, happiness and the warmth of sunshine."
						+ "\n" + " From Revanth Reddy")
				.create();
		message.getSid();

	}

	public static void sendRegistrationSMS(User user) {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		String mobile = "+919901972233";
		if (user.getMobile() != null) {
			mobile = "+91" + user.getMobile();
		}

		Message message = Message.creator(new PhoneNumber(mobile), new PhoneNumber("+16199285746"),
				"Dear " + user.getFirstName() + ", Thanks a lot for Registering to CrazyUsers blog ! " + "\n"
						+ "Have a nice day," + "\n" + "From Revanth Reddy ")
				.create();
		message.getSid();

	}

	public static void sendEventSMS(Task task) {
		task.setName("Crazy User");
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

		Message message = Message.creator(new PhoneNumber("+919901972233"), new PhoneNumber("+16199285746"),
				"Dear " + task.getName() + ", " + task.getMessage() + ". From Revanth Reddy").create();
		message.getSid();

	}

	public static void sendWeddingDaySMS(EmailUser user) {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);
		String mobile = "+91" + user.getContactNo();

		Message message = Message.creator(new PhoneNumber(mobile), new PhoneNumber("+16199285746"),
				"Dear " + user.getName() + "\n" + ", Wishing you happy Wedding Anniversary !" + "\n"
						+ "May God bestow His goodness and blessings on you at all times !"
						+ "\n" + " From Revanth Reddy")
				.create();
		message.getSid();

	}

	public static void main(String[] args) {
	}

}
