package com.crazyusers.springmvc.service;

import java.util.List;

import com.crazyusers.springmvc.model.User;

public interface UserService {

	User findById(int id);

	User findBySSO(String sso);

	User findByEmailId(String sso);

	void saveUser(User user);

	void updateUser(User user);

	void deleteUserBySSO(String sso);

	List<User> findAllUsers();

	boolean isUserSSOUnique(Integer id, String sso);

}