package com.crazyusers.springmvc.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotEmpty;

/**
 * @author revanthreddy
 */

@Entity
@Table(name = "WEDDING")
public class Wedding implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer id;

	@NotNull(message = "Name should not be empty")
	@Column(name = "HUSBAND_NAME", nullable = false)
	private String husband_name;

	@NotNull(message = "Name should not be empty")
	@Column(name = "WIFE_NAME", nullable = false)
	private String wife_name;

	@NotNull(message = "Template Name should not be empty")
	@Column(name = "TEMPLATE_NAME", nullable = false)
	private String template_name;

	@DOBValidator
	@NotEmpty(message = "Date should not be empty")
	@Column(name = "WEDDING_DATE", nullable = false)
	private String wedding_date;

	@NotNull(message = "Image Name should not be empty")
	@Column(name = "IMAGE_NAME", nullable = false)
	private String image_name;

	@NotNull(message = "Message should not be empty")
	@Column(name = "MESSAGE", nullable = false)
	private String message;

	@NotEmpty(message = "Please enter valid email addresss")
	@Email
	@Column(name = "EMAIL", nullable = false)
	private String email;

	public String getTemplate_name() {
		return template_name;
	}

	public void setTemplate_name(String template_name) {
		this.template_name = template_name;
	}

	public String getImage_name() {
		return image_name;
	}

	public void setImage_name(String image_name) {
		this.image_name = image_name;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getHusband_name() {
		return husband_name;
	}

	public void setHusband_name(String husband_name) {
		this.husband_name = husband_name;
	}

	public String getWife_name() {
		return wife_name;
	}

	public void setWife_name(String wife_name) {
		this.wife_name = wife_name;
	}

	public String getWedding_date() {
		return wedding_date;
	}

	public void setWedding_date(String wedding_date) {
		this.wedding_date = wedding_date;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Wedding [id=" + id + ", husband_name=" + husband_name + ", wife_name=" + wife_name + ", template_name="
				+ template_name + ", wedding_date=" + wedding_date + ", image_name=" + image_name + ", message="
				+ message + ", email=" + email + "]";
	}

}
