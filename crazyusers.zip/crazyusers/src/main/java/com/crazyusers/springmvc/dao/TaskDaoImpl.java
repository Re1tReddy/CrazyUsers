/**
 * 
 */
package com.crazyusers.springmvc.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.criterion.CriteriaSpecification;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Restrictions;
import org.springframework.stereotype.Repository;

import com.crazyusers.springmvc.model.Task;

/**
 * @author revanthreddy
 *
 */

@Repository("taskDao")
public class TaskDaoImpl extends AbstractDao<Integer, Task> implements TaskDao {

	@Override
	@SuppressWarnings("unchecked")
	public List<Task> findAllTasks() {
		Criteria criteria = createEntityCriteria().addOrder(Order.asc("event_name"));
		criteria.setResultTransformer(CriteriaSpecification.DISTINCT_ROOT_ENTITY); // To
																					// avoid
																					// duplicates.
		List<Task> task = criteria.list();

		return task;
	}

	/* (non-Javadoc)
	 * @see com.crazyusers.springmvc.dao.TaskDao#findById(int)
	 */
	@Override
	public Task findById(int id) {
		Task task = getByKey(id);
		return task;
	}

	/* (non-Javadoc)
	 * @see com.crazyusers.springmvc.dao.TaskDao#deleteTaskById(int)
	 */
	@Override
	public void deleteTaskById(int id) {
		Criteria crit = createEntityCriteria();
		crit.add(Restrictions.eq("id", id));
		Task task = (Task) crit.uniqueResult();
		delete(task);
		
	}

	/* (non-Javadoc)
	 * @see com.crazyusers.springmvc.dao.TaskDao#saveTask(com.crazyusers.springmvc.model.Task)
	 */
	@Override
	public void saveTask(Task task) {
		persist(task);
		
	}

}
