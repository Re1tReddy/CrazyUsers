package com.crazyusers.springmvc.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.crazyusers.springmvc.dao.WeddingDao;
import com.crazyusers.springmvc.model.Wedding;

/**
 * @author revanthreddy
 *
 */

@Service("weddingService")
@Transactional
public class WeddingServiceImpl implements WeddingService {

	@Autowired
	private WeddingDao dao;

	@Override
	public List<Wedding> findAllWeddings() {
		return dao.findAllWeddings();
	}

	@Override
	public void updateWedding(Wedding wed) {
		Wedding entity = dao.findById(wed.getId());
		if (entity != null) {
			entity.setHusband_name(wed.getHusband_name());
			entity.setWife_name(wed.getWife_name());
			entity.setWedding_date(wed.getWedding_date().trim());
			entity.setEmail(wed.getEmail().trim());
			entity.setImage_name(wed.getImage_name());
			entity.setMessage(wed.getMessage());
			entity.setTemplate_name(wed.getTemplate_name());
		}
	}

	@Override
	public Wedding findById(int id) {

		return dao.findById(id);
	}

	@Override
	public void deleteWeddingById(int id) {
		dao.deleteWeddingById(id);

	}

	@Override
	public void saveWedding(Wedding wed) {
		dao.saveWedding(wed);

	}

}
