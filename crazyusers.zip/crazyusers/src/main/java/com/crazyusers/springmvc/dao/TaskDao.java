/**
 * 
 */
package com.crazyusers.springmvc.dao;

import java.util.List;

import com.crazyusers.springmvc.model.Task;

/**
 * @author revanthreddy
 *
 */
public interface TaskDao {

	List<Task> findAllTasks();

	Task findById(int id);

	void deleteTaskById(int id);

	void saveTask(Task task);
}
