package com.crazyusers.springmvc.dao;

import java.util.List;

import com.crazyusers.springmvc.model.UserProfile;


public interface UserProfileDao {

	List<UserProfile> findAll();
	
	UserProfile findByType(String type);
	
	UserProfile findById(int id);
}
