import com.twilio.Twilio;
import com.twilio.rest.api.v2010.account.Message;
import com.twilio.type.PhoneNumber;

public class SendSMS {

	// Find your Account Sid and Token at twilio.com/user/account
	public static final String ACCOUNT_SID = "AC418055d9472701d9afb5207e735642b6";
	public static final String AUTH_TOKEN = "97649c4545772a79cb0ae936131c0734";

	public static void sendBirthDaySMS() {
		Twilio.init(ACCOUNT_SID, AUTH_TOKEN);

		Message message = Message
				.creator(new PhoneNumber("+919901972233"), new PhoneNumber("+16199285746"),
						"Have a wonderful birthday. I wish your every day to be filled with lots of love, laughter, happiness and the warmth of sunshine. May your coming year surprise you with the happiness of smiles, the feeling of love and so on. I hope you will find plenty of sweet memories to cherish forever ! From Revanth Reddy")
				.create();
		message.getSid();

	}

	public static void main(String[] args) {
		sendBirthDaySMS();
	}

}
